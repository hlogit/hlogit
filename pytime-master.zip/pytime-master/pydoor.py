# pip install Flask
# c:\pypy2.7-v7.0.0-win32\bin\pip.exe install suds requests pyVmomi pyodbc flask werkzeug pyinstaller
import sys
import os
import time
from flask import Flask 
from flask import request
from flask import send_file
from flask import flash, redirect, url_for
from flask import session
import io
import flask
from subprocess32 import check_output, check_call, Popen, PIPE
import shlex
import subprocess32
from werkzeug.utils import secure_filename
import logging
import traceback

app = Flask(__name__)
_os = "Neil's door"
logging.basicConfig(filename='0door.log', level=logging.DEBUG)
 
def pRun(cmd, working_dir="."):
	logging.info("Working Directory: %s" % working_dir)
	try:
		process  = Popen(cmd,  shell=True, stdout=subprocess32.PIPE, cwd=working_dir)
		(output, err) = process.communicate()
		logging.info("output:%s" % output)
		logging.info("error:%s" % err)
	except Exception as e:
		logging.info(" excepyion %s " % traceback.print_exc(file=sys.stdout))
		logging.error('Failed to open file', exc_info=True)
	logging.info("---")
	ret = process.returncode
	logging.info("pRun return code: %d\n" % ret)
	return (output, err)

def execute(cmd, working_dir="."):
	logging.info("Working Directory: %s" % working_dir)
	#cmd = shlex.quote(cmd)
	logging.info("cmd: %s" % cmd)
	output = check_output(cmd,  shell=True, 
				timeout=3,
				stderr=subprocess32.STDOUT,
				universal_newlines=True,
				cwd=working_dir)
	logging.info(output)
	return output
	
@app.route("/run", methods=["GET"])
def run():
	cmd = request.args.get('cmd')
	timestamp = time.strftime('[%Y-%m-%d %H:%M:%S]')
	logging.info("%s REQ CMD is: %s" % (timestamp, cmd))

	try:
		ret = execute(cmd)
	except Exception as e:
		ret = str(e)
		logging.error('Failed to open file', exc_info=True)
	return ret	
	
@app.route("/runw", methods=["GET"])
def runw():
	cmd = request.args.get('cmd')
	timestamp = time.strftime('[%Y-%m-%d %H:%M:%S]')
	logging.info("%s REQ CMD is: %s" % (timestamp, cmd)) 
	try:
		ret = pRun(cmd)
	except Exception as e:
		ret = str(e)
	return ret

@app.route("/get_timestamp", methods=["GET"])
def provide_timestamp():
	ts = time.time()
	logging.info("get_timestamp: %s" % ts)
	return str(ts)
	#return jsonify({'timestamp': ts, "status": 200})
	
@app.route("/get_file", methods=["GET"])
def provide_file():
	# provide to client
	filename = request.args.get('filename')
	logging.info("provide_file: %s" % filename)
	fname = os.path.basename(filename)
	fpath = os.path.dirname(filename) 
	filename0 = os.path.join(fpath, fname)
	#if not os.path.isfile(filename0):
	#	return "no file"
	return flask.send_from_directory(fpath, fname, as_attachment=True, cache_timeout=0)		

	
@app.route("/send_file", methods=["POST"])
def save_file():
	# client upload file
	if not request.method == 'POST':
		#flash('Not a POST')
		logging.info('Not a POST')
		return 'Not a POST'
	# check if the post request has the file part
	if 'file' not in request.files:
		#flash('No file part')
		return 'No file part'
	file = request.files['file']
	# if user does not select file, browser also
	# submit an empty part without filename
	if file.filename == '':
		#flash('No selected file')
		logging.info("No selected file")
		return 'No selected file'
	logging.info("save_file: %s" % file.filename)
	if file:
		filename = secure_filename(file.filename)
		file.save(os.path.join(".", filename))
		return "Done"
		
#<form method="post" enctype=multipart/form-data action="{{ url_for('send_file') }}">
@app.route("/", methods=["GET"])
def page_upload():
	page='''<html>
	<title>Upload new File</title>
	<h1>Upload new File</h1>
	<form method="post" enctype=multipart/form-data action="/send_file">
	<input type=file name=file>
	<input type=submit value=Upload>
	</form></html>'''
	return page
	
if __name__ == '__main__': 
	RESULT_FILE = os.path.join('.', "rest.log")
	app.debug = True
	#app.run()	
	app.run(host="0.0.0.0", port="8080")
	
	'''
	curl http://10.201.113.120:8080/get_file?filename=unzip.exe -o /c/temp/uzip.exe 
	curl -F file=@LICENSE.txt http://10.201.113.120:8080/send_file
	curl http://10.201.113.120:8080/get_timestamp
	curl http://10.201.113.120:8080/run?cmd="dir%20\"c:\\program%20files\" "
	curl -G  http://10.201.113.120:8080/run --data-urlencode "cmd=dir \"c:\program files\""
	http://10.201.113.120:8080/runw?cmd=timeout%20/t%202%26dir
	http://10.201.113.120:8080/runw?cmd=timeout%20/t%2011%26dir
	
	
	'''
	
	
