# pip install grpcio
# pip install grpcio-tools
#
import time
import os
import sys
import platform
import threading

import grpc
import e_pb2 as pb2
import e_pb2_grpc as pb2_grpc



def getCommandOutput(consoleCommand, consoleOutputEncoding="utf-8", timeout=2):
    """get command output from terminal


    Args:
        consoleCommand (str): console/terminal command string
        consoleOutputEncoding (str): console output encoding, default is utf-8
        timeout (int): wait max timeout for run console command
    Returns:
        console output (str)
    Raises:
    """
    # print("getCommandOutput: consoleCommand=%s" % consoleCommand)
    isRunCmdOk = False
    consoleOutput = "NOoutput"
    try:
        # consoleOutputByte = subprocess.check_output(consoleCommand)


        consoleOutputByte = subprocess.check_output(consoleCommand, shell=True, timeout=timeout)


        # commandPartList = consoleCommand.split(" ")
        # print("commandPartList=%s" % commandPartList)
        # consoleOutputByte = subprocess.check_output(commandPartList)
        # print("type(consoleOutputByte)=%s" % type(consoleOutputByte)) # <class 'bytes'>
        # print("consoleOutputByte=%s" % consoleOutputByte) # b'640x360\n'


        consoleOutput = consoleOutputByte.decode(consoleOutputEncoding) # '640x360\n'
        consoleOutput = consoleOutput.strip() # '640x360'
        isRunCmdOk = True
    except subprocess.CalledProcessError as callProcessErr:
        cmdErrStr = str(callProcessErr)
        print("Error %s for run command %s" % (cmdErrStr, consoleCommand))


    # print("isRunCmdOk=%s, consoleOutput=%s" % (isRunCmdOk, consoleOutput))
    return (isRunCmdOk, consoleOutput)

def execute(cmd):
    if len(cmd) > 3:
        pass
    else:
        pass
        print("!!command not good[%s]"% (cmd))
        # tcSend(a_sub_cmd, "!!command not good") 
    # print("a_cmd:[%s] " % (a_cmd))
    if "windows" in platform_system.lower():
        print("__[%s]___is windows run"% (platform_system))
        # input()
        cmd = "start \" %s\" /WAIT cmd /C %s" % (cmd, cmd)##os.path.join(a_cmd, a_cmd))
        # print("________cmd_Ffor win:[%s] " % (a_cmd))
    else:
        pass
    savelog("____final____cmd :[%s] " % (cmd))
    os.system(cmd)



def executesp(yourCommand):
    if len(yourCommand) > 3:
        pass
    else:
        pass
        print("!!command not good[%s]"% (yourCommand))
        # tcSend(a_sub_cmd, "!!command not good") 
    # print("a_cmd:[%s] " % (a_cmd))
    if "windows" in platform_system.lower():
        print("__[%s]___is windows run"% (platform_system))
        # input()
        cmd = "start \" %s\" /WAIT cmd /C %s" % (yourCommand, yourCommand)
        # print("________cmd_Ffor win:[%s] " % (a_cmd))
    else:
        pass
    savelog("____final____cmd :[%s] " % (cmd))
    os.system(cmd)
    
    timeoutSeconds = 250
    (isRunCmdOk, consoleOutput) = getCommandOutput(yourCommand, consoleOutputEncoding="utf-8", timeout=timeoutSeconds)
    savelog("consoleOutput: %s" % (consoleOutput))
# subprocess.check_output(yourCommand, shell=True, timeout=timeoutSeconds)

def getDateTimesr():
    timestamp = time.strftime('%Y%m%d%H%M%S')
    return timestamp

def getDateTimesr2fmt():
    timestamp = time.strftime('%Y-%m-%d %H:%M:%S')
    return timestamp

import grpc
import e_pb2 as pb2
import e_pb2_grpc as pb2_grpc

channel = grpc.insecure_channel("127.0.0.1:16631")
client = pb2_grpc.pytimeOutputStub(channel=channel)




def uploadToServer(msg):
    import logging

    from opencensus.ext.azure.log_exporter import AzureLogHandler

    logger = logging.getLogger(__name__)
    # TODO: replace the all-zero GUID with your instrumentation key.
    logger.addHandler(AzureLogHandler(
        connection_string='InstrumentationKey=87fe959b-8ba3-4154-a8b7-ca830f845df0')
    )
    properties = {'custom_dimensions': msg}

    # Use properties in logging statements
    logger.warning('action', extra=properties)


def uploadToServer2(msg):
    response = client.hello_pytime(
        pb2.request(data=str(msg), undef=int(1))
    )
    print(response.result)


def savelog(msg):
    K = time.time()
    # print(msg)    
    with open(pytimeLog, "a+") as fp:
        fp.write("\n"+str(msg))
    print("___pytimeLog file:[%s] " % (pytimeLog))
    return

startTime = getDateTimesr()
pytimeLog = "0pytime%s.log"%(startTime)
print("pytimeLog file:[%s] " % (pytimeLog))
platform_system = platform.system()
savelog("fplatform_system:%s " % (platform_system.lower()))
data = {}
data['platform_system'] = platform_system
data['prog_startTime'] = startTime

def main(Round):
    pid = os.getpid()
    savelog("pid: %s" % (pid))
    tid = thread_id = threading.current_thread().ident
    savelog("tid: %s" % (tid))
    savelog("\n\nNow time: %s" % (getDateTimesr2fmt()))
    # full_cmd = "timeout /t 2 ' '' ''"
    data['pid'] = pid
    data['tid'] = tid
    savelog(sys.argv)
    a_cmd = sys.argv[1]
    savelog("a_cmd: %s" % (a_cmd))
    full_cmd = '__'.join(sys.argv)
    data['full_cmd'] = full_cmd
    savelog("full_cmd: %s" % (full_cmd))
    # print(full_cmd)
    try:
        pass
    except Exception as e:
        print(e)
        exc_type, exc_obj, exc_tb = sys.exc_info()
        fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
        print(exc_type, fname, exc_tb.tb_lineno)
        sys.exit()
    finally:
        pass
        # cmd = "timeout /t 2 "
    fullcmd_str = full_cmd.translate({ord(c): "_" for c in "!@#$%^&*()[]{};:,./<>?\|`~-=_+"})
    a_sub_cmd_sp = a_cmd.split(' ')
    savelog("a_sub_cmd: %s" % (a_sub_cmd_sp[0]))
    a_sub_cmd_argv = a_sub_cmd_sp[1:]
    savelog("a_sub_cmd_argv: %s" % (a_sub_cmd_argv))
    # a_sub_cmd = 
    test_start_ts = time.time()
    data['Round'] = Round
    data['test_start_ts'] = test_start_ts
    data['test_cmd'] = a_cmd
    print(data)
    uploadToServer(data)
    runcmd = "start \"%s\"  /WAIT  cmd /K %s  " % (a_cmd, a_cmd)
    execute(a_cmd)
    print(data)
    uploadToServer(data)
    test_end_ts = time.time()
    test_duration = float(test_end_ts) - float(test_start_ts)
    data['test_end_ts'] = test_end_ts
    data['test_duration'] = test_duration
    savelog("--Round:%s--Execution time: %s" % (Round,str(test_duration)))
    savelog(data)
    print(data)
    uploadToServer(data)


if __name__ == '__main__':
    try:
        repeatCount = int(sys.argv[2])
    except Exception as e:
        
        savelog(e)
        repeatCount =1
    for Round in range(1 , repeatCount+1, 1):
    # for Round in range(2):
        main(Round)
        savelog(" -end- Rround -- : %s" % (Round))
    