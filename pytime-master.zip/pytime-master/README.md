python pytime.py  "timeout /t 2 "   3

the 3 is repeat times. and it contains grpc client.

pytimer.py to run a command can get the command execution time/related json data and  save a log file in local.

the ser.py is a grpc server. if you have run ser.py.  while the grpcserver recieved the execution results from client. it can do somesthing EX: sent data to applicationinsight.
so, you can chang the upload() to send the execution json data to what you want.

pydoor.py is a tool like  backdoor using http protocol. .which can be use to execute/get/upload file in the target which running pydoor.py.
see the bottom for usage 

Neil Lo 16631 on 2007/0319~2021/02/17
