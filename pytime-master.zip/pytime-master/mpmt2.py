# -*- coding: utf-8
import  os
from concurrent.futures import ThreadPoolExecutor, as_completed
import  concurrent.futures as cf


def say_hello_to(name):
    os.system(name)
    return f'Hi, {name}'

'''

names = [r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\Manager-Windows-20.0.331.x64.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\AcronisTrueImage2021.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\tb_free.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\VMware-workstation-full-16.1.0-17198959.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\Manager-Windows-20.0.331.x64.exe   sha256"]

with ThreadPoolExecutor(max_workers=5) as executor:
    results = executor.map(say_hello_to, names)

for r in results:
    print(r)


#-----------------------------------------------------------------------------------------------------
'''
from concurrent.futures import ThreadPoolExecutor, as_completed

def say_hello_to(name):
    return f'Hi, {name}'

names = [r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\Manager-Windows-20.0.331.x64.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\AcronisTrueImage2021.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\tb_free.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\VMware-workstation-full-16.1.0-17198959.exe   sha256", 
r"CertUtil -hashfile   C:\Users\neil_lo\Downloads\Manager-Windows-20.0.331.x64.exe   sha256"]

with ThreadPoolExecutor(max_workers=5) as executor:
    futures = []
    for n in names:
        future = executor.submit(say_hello_to, n)
        print(type(future))
        futures.append(future)

    for future in as_completed(futures):
        print(future.result())
		
		

'''

